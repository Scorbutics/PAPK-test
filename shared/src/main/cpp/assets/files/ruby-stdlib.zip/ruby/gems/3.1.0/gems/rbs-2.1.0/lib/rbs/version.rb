module RBS
  VERSION = "2.1.0"
end
