warn "The verbose formatter has been removed and now `require 'did_you_mean/verbose'` has no effect. Please " \
     "remove this call."
